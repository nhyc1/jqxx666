﻿import pandas as pd
import jieba
import numpy as np
import re
datas = pd.read_csv('train.csv')
print("读取前10行训练集数据，确认训练调用正确：")
#读取前20条数据
print(datas.head(10))
 #获得停用词表`
def getStopWords():
    stopList=[]
    for line in open("中文停用词表.txt"):
        stopList.append(line[:len(line)-1])
    return stopList;
def loadDataSet(data):
    #
    # 数据预处理，去掉特殊字符和不关键的字词
    # 过滤评论label：  涉及食品安全：1     非食品安全：0
    comment = []
    label = []
    include_list = getStopWords()
    character = '[a-zA-Z2-9’!"#$%&\'()*+,-./:;<=>?@，。?★、…【】《》？～“”‘’！❤️[\\]^_`{|}~\s]+'
    for line in data:
        lines = str(line).strip().strip("['']")
        #去掉特殊字符
        lines = re.sub(character, "", lines)
        #去掉非关键词
        for key in include_list:
            lines = lines.replace(key,'')
        lines = lines.split('\\')
        if((lines[0] == "0") or (lines[0] == "1")):
            label.append(int(lines[0]))
        else:
            label.append(0)
        comment.append(lines[1])
    class_comment = [[0 for i in range(0)] for j in range(len(comment))]
    #数据内容进行jieba分词
    i = 0
    for line in comment:
        line = list(jieba.cut_for_search(str(line)))
        for lines in line:
            class_comment[i].append(lines)
        i=i+1
    return class_comment, label

#获取测试文件
def loadTestDataSet(data):
    comment = []
    include_list = getStopWords()
    character = '[a-zA-Z2-9’!"#$%&\'()*+,-./:;<=>?@，。?★、…【】《》？～“”‘’！❤️[\\]^_`{|}~\s]+'
    for line in data:
        lines = str(line).strip().strip("['']")
        #去掉特殊字符
        lines = re.sub(character, "", lines)
        #去掉非关键词
        for key in include_list:
            lines = lines.replace(key,'')
        comment.append(lines)
    class_comment = [[0 for i in range(0)] for j in range(len(comment))]
    #数据内容进行jieba分词
    i = 0
    for line in comment:
        line = list(jieba.cut_for_search(str(line)))
        for lines in line:
            class_comment[i].append(lines)
        i=i+1
    return comment
# 创建一个包含在所有文档中出现的不重复词的列表
def createVocabList(dataSet):
    vocabSet = set([])      # 创建一个空集
    for document in dataSet:
        vocabSet = vocabSet | set(document)   # 创建两个集合的并集
    return list(vocabSet)

# 将文档词条转换成词向量
def setOfWords2Vec(vocabList, inputSet):
    returnVec = [0]*len(vocabList)        # 创建一个其中所含元素都为0的向量
    for word in inputSet:
        if word in vocabList:
            # returnVec[vocabList.index(word)] = 1     # index函数在字符串里找到字符第一次出现的位置  词集模型
            returnVec[vocabList.index(word)] += 1      # 文档的词袋模型    每个单词可以出现多次
        else:
            pass
            #print ("the word: %s is not in my Vocabulary!" % word)
    return returnVec

# 朴素贝叶斯分类器训练函数   从词向量计算概率
def trainNB0(trainMatrix, trainCategory):
    numTrainDocs = len(trainMatrix)
    numWords = len(trainMatrix[0])
    pAbusive = sum(trainCategory)/float(numTrainDocs)
    # p0Num = zeros(numWords); p1Num = zeros(numWords)
    # p0Denom = 0.0; p1Denom = 0.0
    p0Num = np.ones(numWords);   # 避免一个概率值为0,最后的乘积也为0
    p1Num = np.ones(numWords);   # 用来统计两类数据中，各词的词频
    p0Denom = 2.0;  # 用于统计0类中的总数
    p1Denom = 2.0  # 用于统计1类中的总数
    for i in range(numTrainDocs):
        if trainCategory[i] == 1:
            p1Num += trainMatrix[i]
            p1Denom += sum(trainMatrix[i])
        else:
            p0Num += trainMatrix[i]
            p0Denom += sum(trainMatrix[i])
            # p1Vect = p1Num / p1Denom
            # p0Vect = p0Num / p0Denom
    p1Vect = np.log(p1Num / p1Denom)  # 在类1中，每个词的发生概率
    p0Vect = np.log(p0Num / p0Denom)  # 避免下溢出或者浮点数舍入导致的错误   下溢出是由太多很小的数相乘得到的
    return p0Vect, p1Vect, pAbusive

# 朴素贝叶斯分类器
def classifyNB(vec2Classify, p0Vec, p1Vec, pClass1):
    p1 = sum(vec2Classify * p1Vec) + np.log(pClass1)
    p0 = sum(vec2Classify * p0Vec) + np.log(1.0 - pClass1)
    if p1 > p0:
        return 1
    else:
        return 0


def forecast():
    df = pd.read_csv('train.csv')#读取文件内容
    data = np.array(df)#将文件存储在一个数组中
    listOPosts,listClasses = loadDataSet(data)#得到训练集的词条，及label
    myVocabList = createVocabList(listOPosts)#创建一个集合来存储词条，每个词条只存一遍，采用的是并集处理的思想方式
    trainMat = []#设置一个空集

    print("训练。。。。")
    for postinDoc in listOPosts:
        trainMat.append(setOfWords2Vec(myVocabList, postinDoc)) #将文档词条转化为词向量，存储在上面定义的空集 trainMat中
    p0V, p1V, pAb = trainNB0(np.array(trainMat), np.array(listClasses))#用三个变量存储训练训练集得到1盒0类中每个词发生的概率
    print("预测。。。。")
    test_label_list = [] #设置一个空集合
    test_df = pd.read_csv('test_new.csv')#读取测试集的内容
    print("读取前10行测试集数据，确认测试调用正确：")
    print(test_df.head(10))
    test_data = np.array(test_df["comment"])#将测试集中的comment列存储到数据集合test_id中
    test_id = list(np.array(test_df["id"]))#将测试集中的id列存储到集合test_id 中
    comment = loadTestDataSet(test_data)#得到测试集的词条
    for testEntry in comment:
        thisDoc = np.array(setOfWords2Vec(myVocabList, testEntry))#将词条转化为词向量A
        test_label_list.append(classifyNB(thisDoc, p0V, p1V, pAb))#根据训练集的训练出来的词向量和测试集的词向量，通过比较2类的概率，得到lable的值存入集合中
    # 写入文件保存
    print("保存数据。。。。")
    dataframe = pd.DataFrame({'id': test_id, 'label': test_label_list})#设置一个dataframe存储器，对得到的用户id和lable进行存储
    # 将DataFrame存储为csv,index表示是否显示行名，default=True
    dataframe.to_csv("./forecast.csv", index=False, sep=',')

forecast()#调用函数进行预测，得到预测表
datas1=pd.read_csv("./forecast.csv")#读取出的csv表格
print("打印预测表的前10行，保证结果格式的正确性：")
print(datas1.head(10))#打印出预测表的前10行数据